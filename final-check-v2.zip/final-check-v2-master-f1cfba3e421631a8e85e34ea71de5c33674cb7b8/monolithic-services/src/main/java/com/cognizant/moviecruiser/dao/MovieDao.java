package com.cognizant.moviecruiser.dao;

import java.util.List;

import com.cognizant.moviecruiser.model.Movie;

/**
 * @author 805972
 *
 */
public interface MovieDao {

	/**Stores the movie list in the Admin perspective
	 * @return Returns the admin's movie list
	 */
	public List<Movie> getMovieListAdmin();

	/**Stores the movie list in the Customer perspective
	 * @return Returns the customer's movie list
	 */
	public List<Movie> getMovieListCustomer();

	/**Modifies the movie in the respective input id object.
	 * @param movie
	 */
	public void modifyMovie(Movie movie);

	/**Stores the new movie object in the instance.
	 * @param movieId
	 * @return Returns the movie.
	 */
	public Movie getMovie(long movieId);

}
