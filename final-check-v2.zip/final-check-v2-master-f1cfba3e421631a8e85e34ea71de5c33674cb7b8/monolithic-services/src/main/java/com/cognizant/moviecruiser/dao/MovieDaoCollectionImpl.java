package com.cognizant.moviecruiser.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.MovieCruiserConstants;

/**
 * @author 805972
 *
 */
@Component
public class MovieDaoCollectionImpl implements MovieDao {
	
	public static ArrayList<Movie> movieList;
	
	/**Stores the movie details in the object.
	 * 
	 */
	public MovieDaoCollectionImpl() {
		ApplicationContext context = new ClassPathXmlApplicationContext("moviecruiser.xml");
		movieList = context.getBean("movies",ArrayList.class);
		MovieCruiserConstants.LOGGER.debug("in super");
		for(Movie movie:movieList) {
			MovieCruiserConstants.LOGGER.debug(movie.toString());
		}
	}
	
	/**Stores the movie list in the Admin perspective
	 * @return Returns the admin's movie list
	 */
	@Override
	public List<Movie> getMovieListAdmin() {
		MovieCruiserConstants.LOGGER.debug("in get admin");
		return movieList;
	}
	
	/**Stores the movie list in the Customer perspective
	 * @return Returns the customer's movie list
	 */
	@Override
	public List<Movie> getMovieListCustomer() {
		MovieCruiserConstants.LOGGER.debug("in get admin");
		List<Movie> movieListCustomer = new ArrayList<Movie>();
		for (Movie movie : movieList) {
			Date launchDate = movie.getDateOfLaunch();
			Date today = new Date();
			boolean isActive = movie.isActive();
			if ((launchDate.before(today) || launchDate.equals(today)) && isActive) {
				movieListCustomer.add(movie);
			}
		}
		return movieListCustomer;
	}
	
	/**Modifies the movie in the respective input id object.
	 * @param movie
	 */
	@Override
	public void modifyMovie(Movie movie) {
		for (int i = 0; i < movieList.size(); i++) {
			if (movieList.get(i).equals(movie)) {
				movieList.set(i, movie);
				break;
			}
		}
	}
	
	/**Stores the new movie object in the instance.
	 * @param movieId
	 * @return Returns the movie.
	 */
	@Override
	public Movie getMovie(long movieId) {
		Movie movie = null;
		for (Movie movieObj : movieList) {
			if (movieObj.getId() == movieId) {
				movie = movieObj;
				break;
			}
		}
		return movie;
	}
	
}