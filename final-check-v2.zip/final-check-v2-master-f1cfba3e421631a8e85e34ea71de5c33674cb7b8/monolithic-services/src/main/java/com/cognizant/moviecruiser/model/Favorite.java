package com.cognizant.moviecruiser.model;

import java.util.List;

/**
 * @author 805972
 *
 */
public class Favorite {

	
	private List<Movie> favorites;
	private int noOfFavorite;

	public Favorite() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Favorite(List<Movie> favorites, int noOfFavorite) {
		super();
		this.favorites = favorites;
		this.noOfFavorite = noOfFavorite;
	}


	public List<Movie> getFavorites() {
		return favorites;
	}

	public void setFavorites(List<Movie> favorites) {
		this.favorites = favorites;
	}

	public int getnoOfFavorite() {
		return noOfFavorite;
	}

	public void setnoOfFavorite(int count) {
		this.noOfFavorite = count;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + noOfFavorite;
		result = prime * result + ((favorites == null) ? 0 : favorites.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Favorite other = (Favorite) obj;
		if (noOfFavorite != other.noOfFavorite)
			return false;
		if (favorites == null) {
			if (other.favorites != null)
				return false;
		} else if (!favorites.equals(other.favorites))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Favorite [favorites=" + favorites + ", noOfFavorite=" + noOfFavorite + "]";
	}

}