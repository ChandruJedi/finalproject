package com.cognizant.moviecruiser.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cognizant.moviecruiser.MovieCruiserConstants;
import com.cognizant.moviecruiser.exception.FavoriteEmptyException;
import com.cognizant.moviecruiser.model.Favorite;
import com.cognizant.moviecruiser.model.Movie;

/**
 * @author 805972
 *
 */
@Component
public class FavoriteDaoCollectionImpl implements FavoriteDao {

	private static HashMap<String, Favorite> userFavorites;

	/**
	 * Creates a new Hashmap in the user favorites.
	 * 
	 */
	public FavoriteDaoCollectionImpl() {
		if (userFavorites == null) {
			userFavorites = new HashMap<String, Favorite>();
		}
	}

	/**
	 * Adds favorite movie in the map.
	 * 
	 * @param userId
	 * @param movieId
	 */
	@Override
	public void addFavoriteMovie(String userId, long movieId) {
		MovieDao movieDao = new MovieDaoCollectionImpl();
		Movie movie = movieDao.getMovie(movieId);
		MovieCruiserConstants.LOGGER.debug(""+userId);
		System.out.println(userFavorites.containsKey(userId));
		if (userFavorites.containsKey(userId)) {
			System.out.println("coming here");
			Favorite favorites = userFavorites.get(userId);
			List<Movie> movieList = favorites.getFavorites();
			movieList.add(movie);
		} else {
			System.out.println("New Favorite");
			Favorite favorites = new Favorite(new ArrayList<Movie>(), 0);
			List<Movie> movieList = favorites.getFavorites();
			movieList.add(movie);
			userFavorites.put(userId, favorites);
		}
	}

	/**
	 * Calculates total favorites and returns movie list respective to the user Id.
	 * 
	 * @param userId
	 * @return Returns all the favorite movie
	 * @throws FavoriteEmptyException
	 */
	@Override
	public Favorite getAllFavorites(String userId) throws FavoriteEmptyException {
//		if (userFavorites.containsKey(userId)) {
//			Favorite favorite = userFavorites.get(userId);
//			List<Movie> movies = favorite.getFavorites();
//			if (movies.isEmpty()) {
//				MovieCruiserConstants.LOGGER.info("empty to fav working");
//				throw new FavoriteEmptyException();
//			} else {
//				favorite.setnoOfFavorite(movies.size());
//				return favorite;
//			}
//
//		} else {
//			MovieCruiserConstants.LOGGER.info("empty to fav working");
//			throw new FavoriteEmptyException();
//		}
		System.out.println(userId);
		System.out.println(userFavorites.containsKey(userId));
		if (userFavorites.containsKey(userId)) {
			Favorite favorite = userFavorites.get(userId);
			List<Movie> favoriteMovies = favorite.getFavorites();
			if (favoriteMovies.isEmpty()) {
				throw new FavoriteEmptyException();
			} else {
				favorite.setnoOfFavorite(favoriteMovies.size());
			}
			return favorite;
		} else {
			throw new FavoriteEmptyException();
		}
	}

	/**
	 * Removes the favorite movie in the map.
	 * 
	 * @param userId
	 * @param movieId
	 */
	@Override
	public void removeFavoriteMovie(String userId, long movieId) {
		Favorite favorite = userFavorites.get(userId);
		List<Movie> movies = favorite.getFavorites();
		for (Movie movie : movies) {
			if (movie.getId() == movieId) {
				movies.remove(movie);
				break;
			}
		}
		favorite.setnoOfFavorite(movies.size());
	}

}
