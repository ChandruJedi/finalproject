package com.cognizant.moviecruiser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class MovieCruiserConstants {
	public static final Logger LOGGER= LoggerFactory.getLogger(MovieCruiserApplication.class);
}
