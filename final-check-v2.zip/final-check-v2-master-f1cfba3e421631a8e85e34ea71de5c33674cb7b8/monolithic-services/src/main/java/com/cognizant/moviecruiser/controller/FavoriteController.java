package com.cognizant.moviecruiser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.moviecruiser.MovieCruiserConstants;
import com.cognizant.moviecruiser.dto.FavoriteDTO;
import com.cognizant.moviecruiser.exception.FavoriteEmptyException;
import com.cognizant.moviecruiser.model.Favorite;
import com.cognizant.moviecruiser.service.FavoriteService;


@RestController
@RequestMapping("/favorites")
public class FavoriteController {
	@Autowired FavoriteService favoriteService;
	
	@PostMapping("/{userId}/{movieId}")
	public void addFavoriteMovie(@PathVariable String userId, @PathVariable int movieId){
		MovieCruiserConstants.LOGGER.debug(userId+" "+movieId);
//		MovieCruiserConstants.LOGGER.debug(userId+"=user movieId="+movieId);
		favoriteService.addFavoriteMovie(userId, movieId);
	}
	@GetMapping("/{userId}")
	public  FavoriteDTO getAllFavorites(@PathVariable String userId) throws FavoriteEmptyException{
		 MovieCruiserConstants.LOGGER.info("inside Controller"+userId);
		return favoriteService.getAllFavorites(userId);
	}
	
	@DeleteMapping("/{userId}/{movieId}")
	public void removeFavoriteMovie(@PathVariable String userId, @PathVariable int movieId) {
		favoriteService.removeFavoriteMovie(userId, movieId);
	}
}
