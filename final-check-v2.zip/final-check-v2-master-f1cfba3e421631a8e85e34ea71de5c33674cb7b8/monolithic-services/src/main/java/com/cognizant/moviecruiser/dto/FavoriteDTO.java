package com.cognizant.moviecruiser.dto;

import java.util.List;
import java.util.Set;

import com.cognizant.moviecruiser.model.Movie;

/**
 * @author 805972
 *
 */
public class FavoriteDTO {
	private List<Movie> favorites;
	private int noOfFavorite;
	public FavoriteDTO(List<Movie> favorites, int noOfFavorite) {
		super();
		this.favorites = favorites;
		this.noOfFavorite = noOfFavorite;
	}

	

	public FavoriteDTO() {
		super();
		// TODO Auto-generated constructor stub
	}



	public List<Movie> getFavorites() {
		return favorites;
	}



	public void setFavorites(List<Movie> list) {
		this.favorites = list;
	}



	public int getNoOfFavorite() {
		return noOfFavorite;
	}



	public void setNoOfFavorite(int noOfFavorite) {
		this.noOfFavorite = noOfFavorite;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((favorites == null) ? 0 : favorites.hashCode());
		result = prime * result + noOfFavorite;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FavoriteDTO other = (FavoriteDTO) obj;
		if (favorites == null) {
			if (other.favorites != null)
				return false;
		} else if (!favorites.equals(other.favorites))
			return false;
		if (noOfFavorite != other.noOfFavorite)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "FavoriteDTO [favorites=" + favorites + ", noOfFavorite=" + noOfFavorite + "]";
	}

	
}