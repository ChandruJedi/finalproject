package com.cognizant.moviecruiser.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author 805972
 *
 */
//@SuppressWarnings("serial")
@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Nothing exists")
public class FavoriteEmptyException extends Exception {

	/**
	 * 
	 */
//	private static final long serialVersionUID = 1L;

	public FavoriteEmptyException() {
		super();
	}

}
