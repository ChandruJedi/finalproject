package com.cognizant.moviecruiser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.moviecruiser.MovieCruiserConstants;
import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.security.UserDetailService;
import com.cognizant.moviecruiser.service.MovieService;

@RestController
@RequestMapping("/movies")
public class MovieController {
	@Autowired 
	private MovieService movieService;
	@Autowired private UserDetailService userDetailService;
	public void setmovieService(MovieService movieService) {
		MovieCruiserConstants.LOGGER.debug("Inside menulist Control");
		this.movieService=movieService;
	}
	@GetMapping
	public List<Movie> getAllMovies(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
				
		MovieCruiserConstants.LOGGER.debug(user);
		if (!user.equals("anonymousUser")) {
			UserDetails userDetails = userDetailService.loadUserByUsername(user);
			String role = userDetails.getAuthorities().toArray()[0].toString();
			MovieCruiserConstants.LOGGER.debug("ROLE OF LOGGED IN USER -> " + role);
			if (role.equals("ADMIN")) {
				return movieService.getMovieListAdmin();
			} else {
				return movieService.getMovieListCustomer();
			}
		} else {
			return movieService.getMovieListCustomer();
		}
	}
	
	@GetMapping("/{id}")
	public Movie getMovie(@PathVariable int id) {
		return movieService.getMovie(id);
	}
	
	@PutMapping
	public void modifyMovie(@RequestBody Movie movie){
		MovieCruiserConstants.LOGGER.debug("control "+movie.toString());
		movieService.modifyMovie(movie);
	}
}
