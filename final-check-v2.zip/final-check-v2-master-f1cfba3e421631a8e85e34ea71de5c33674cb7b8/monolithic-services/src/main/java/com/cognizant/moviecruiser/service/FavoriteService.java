package com.cognizant.moviecruiser.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.moviecruiser.dto.FavoriteDTO;
import com.cognizant.moviecruiser.exception.FavoriteEmptyException;
import com.cognizant.moviecruiser.model.Favorite;
import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.model.User;
import com.cognizant.moviecruiser.repository.MovieRepository;
import com.cognizant.moviecruiser.repository.UserRepository;
@Service
public class FavoriteService {
	@Autowired UserRepository userRepository;
	@Autowired MovieRepository movieRepository;
	@Transactional
	public void addFavoriteMovie(String userId, int movieId) {
		User user=userRepository.findByUsername(userId);
		Movie movie=movieRepository.findById(movieId).get();
		if(user.getMovies()==null) {
			user.setMovies(new ArrayList<Movie>());
		}
		user.getMovies().add(movie);
		userRepository.save(user);
	}
	
	@Transactional
	public FavoriteDTO getAllFavorites(String userId) throws FavoriteEmptyException {
		FavoriteDTO favDTO = new FavoriteDTO();
		List<Movie> list = userRepository.getMenuItems(userId);
		if (list == null || list.isEmpty()) {
			throw new FavoriteEmptyException();
		} else {
			favDTO.setFavorites(list);
			favDTO.setNoOfFavorite(userRepository.getNoOfFav(userId));
			return favDTO;
		}
	}
	
	@Transactional
	public void removeFavoriteMovie(String userId, int menuItemId) {
		User users=userRepository.findByUsername(userId);
		List<Movie> list=users.getMovies();
		for(Movie menuItem:list) {
			if(menuItem.getId()==menuItemId) {
				list.remove(menuItem);
				break;
			}
		}
		users.setMovies(list);
		userRepository.save(users);
	}
}
