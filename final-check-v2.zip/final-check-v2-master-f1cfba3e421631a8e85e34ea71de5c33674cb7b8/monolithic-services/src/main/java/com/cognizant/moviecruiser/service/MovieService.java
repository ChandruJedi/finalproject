package com.cognizant.moviecruiser.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.moviecruiser.MovieCruiserConstants;
import com.cognizant.moviecruiser.dao.MovieDaoCollectionImpl;
import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.repository.MovieRepository;

@Service
public class MovieService {
	@Autowired MovieRepository movieRepository;
	public List<Movie> getMovieListCustomer(){
		return movieRepository.getMovieListCustomer();
	}
	public List<Movie> getMovieListAdmin(){
		return movieRepository.findAll();
	}
	public void modifyMovie(Movie movie) {
		MovieCruiserConstants.LOGGER.debug("ser "+movie.toString());
		movieRepository.save(movie);
	}
	public Movie getMovie(int movieId) {
		return movieRepository.findById(movieId).get();
	}
}
