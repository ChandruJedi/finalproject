package com.cognizant.moviecruiser.dao;

import com.cognizant.moviecruiser.exception.FavoriteEmptyException;
import com.cognizant.moviecruiser.model.Favorite;

public interface FavoriteDao {
	
	/**Adds favorite movie in the map.
	 * @param userId
	 * @param movieId
	 */
	public void addFavoriteMovie(String userId, long movieId);

	/**Calculates total favorites and returns movie list respective to the user Id.
	 * @param userId
	 * @return Returns all the favorite movie
	 * @throws FavoriteEmptyException
	 */
	public Favorite getAllFavorites(String userId) throws FavoriteEmptyException;

	/**Removes the favorite movie in the map.
	 * @param userId
	 * @param movieId
	 */
	public void removeFavoriteMovie(String userId, long movieId);
	
}
