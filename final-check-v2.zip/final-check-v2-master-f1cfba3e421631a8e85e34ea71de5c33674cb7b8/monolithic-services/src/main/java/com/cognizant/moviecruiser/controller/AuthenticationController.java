package com.cognizant.moviecruiser.controller;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.moviecruiser.MovieCruiserConstants;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
public class AuthenticationController {
	@GetMapping("/authenticate")
	public Map<String,String> authenticate(@RequestHeader("Authorization") String authHeader) {
		MovieCruiserConstants.LOGGER.info("Start");
		String role = SecurityContextHolder.getContext().getAuthentication()
                .getAuthorities().toArray()[0].toString();
		HashMap<String,String> token = new HashMap<>();
		token.put("token",generateJwt(getUser(authHeader)));
		token.put("role", role);
		MovieCruiserConstants.LOGGER.info("End");
		return token;
	}
	
	
	 private String getUser(String authHeader) {
		 MovieCruiserConstants.LOGGER.info("Start");
			String encodedCredentials = authHeader.split(" ")[1];
			 byte[] h = Base64.getDecoder().decode(encodedCredentials);
			 String user=new String(h).split(":")[0];
			 MovieCruiserConstants.LOGGER.info(user);
			 MovieCruiserConstants.LOGGER.info("End");
			 return user;
	 }
	 
	 private String generateJwt(String user) {
		 JwtBuilder builder = Jwts.builder();
	        builder.setSubject(user);
	        builder.setIssuedAt(new Date());
	        builder.setExpiration(new Date((new Date()).getTime() + 1200000));
	        builder.signWith(SignatureAlgorithm.HS256, "secretkey");
	        String token = builder.compact();
	        return token;
	 }
}
