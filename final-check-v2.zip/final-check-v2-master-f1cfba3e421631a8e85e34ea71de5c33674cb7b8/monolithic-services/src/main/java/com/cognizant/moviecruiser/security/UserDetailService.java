package com.cognizant.moviecruiser.security;

import java.util.HashSet;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//
//import com.cognizant.truyum.model.User;
//import com.cognizant.truyum.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.moviecruiser.exception.UserAlreadyExistsException;
import com.cognizant.moviecruiser.model.Role;
import com.cognizant.moviecruiser.model.User;
import com.cognizant.moviecruiser.repository.RoleRepository;
import com.cognizant.moviecruiser.repository.UserRepository;

@Service
public class UserDetailService implements UserDetailsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserDetailService.class);
	@Autowired private UserRepository userRepository;
	@Autowired private RoleRepository roleRepository; 
	public UserDetailService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String user) throws UsernameNotFoundException {
		LOGGER.debug("Begin");
		User user1 = userRepository.findByUsername(user);
		if (user1 == null) {
			throw new UsernameNotFoundException("User not found !!!");
		}
		LOGGER.debug("End");
		return new AppUser(user1);
	}
	public void signup(User user) throws UserAlreadyExistsException {
		User userNew=userRepository.findByUsername(user.getUsername());
		LOGGER.debug("role begin");
		if(userNew==null) {
			LOGGER.debug("role end 1");
			Role role=roleRepository.findById(2).get();
			LOGGER.debug("role end 2");
			user.setRole(new HashSet<Role>());
			LOGGER.debug("role end 2d");
			user.getRole().add(role);
			LOGGER.debug("role end 2dd");
			userRepository.save(user);

			LOGGER.debug("role end");
		} else {
			throw new UserAlreadyExistsException();
		}
	}
	
	
}
