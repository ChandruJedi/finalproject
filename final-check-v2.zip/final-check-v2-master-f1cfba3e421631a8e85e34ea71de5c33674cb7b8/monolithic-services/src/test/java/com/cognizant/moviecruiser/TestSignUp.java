/**
 * @author 805972
 *
 */
package com.cognizant.moviecruiser;

import static org.junit.jupiter.api.Assertions.assertNotNull;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cognizant.moviecruiser.controller.UserController;
import com.cognizant.moviecruiser.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author 805972
 *
 */
//@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class TestSignUp {
	@Autowired
	private MockMvc mvc;
//	@Autowired private MenuItemController menuItemController;
//	@Test
//	void contextLoads() {
//		assertNotNull(menuItemController);
//	}
//	 @Test
//    public void testGetMenu() throws Exception {
//	 ResultActions actions = mvc.perform(get("/truyum"));
//	 actions.andExpect(status().isOk());
//	 actions.andExpect(jsonPath("$.code").exists());
//	 actions.andExpect(jsonPath("$.code").value("1"));
//	 actions.andExpect(jsonPath("$.name").exists());
//	 actions.andExpect(jsonPath("$.name").value("Sandwich"));
//    }
//	 @Test
//	public void testGetMenuItem() throws Exception {
//		 ResultActions actions = mvc.perform(get("/menu-items/1"));
//		 actions.andExpect(status().isNotFound());
//	        actions.andExpect(status().reason("Menu Item not found"));
//	 }
	@Autowired
	private UserController userController;

//	@Test
	void contextLoads() {
		assertNotNull(userController);
	}

	//@Test
	public void testSignUp() throws Exception {
		User user = new User();
		user.setUsername("dgawd");
		user.setFirstname("dawd");
		user.setLastname("dwa");
		user.setPassword("dada");
		mvc.perform(MockMvcRequestBuilders.post("/users").content(asJsonString(user))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isNotFound());

	}
	
//	@Test
	private static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	
}
}
