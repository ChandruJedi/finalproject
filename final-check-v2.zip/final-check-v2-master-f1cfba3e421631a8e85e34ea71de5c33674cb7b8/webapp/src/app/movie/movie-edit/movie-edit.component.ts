import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MovieService } from '../../services/movie.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Movie } from '../movie';
import { MovieListService } from 'src/app/services/movie-list.service';

@Component({
  selector: 'app-movie-edit',
  templateUrl: './movie-edit.component.html',
  styleUrls: ['./movie-edit.component.css']
})
export class MovieEditComponent implements OnInit {

  editForm: FormGroup;
  editMovie = false;
  error: string;
  constructor(private movieListService: MovieListService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.editForm = new FormGroup({
      'id':new FormControl(null),
      'title': new FormControl(null, [Validators.required, Validators.maxLength(200)]),
      'imageUrl': new FormControl(null, [Validators.required]),
      'dateOfLaunch': new FormControl(null, [Validators.required, Validators.pattern('^[0-9]+$')]),
      'boxOffice': new FormControl(null),
      'hasTeaser': new FormControl(null),
      'active': new FormControl(null, Validators.required),
      'genre': new FormControl(null, Validators.required),
    });
    this.route.params.subscribe((params: Params) => {
      const id = params['id'];
      this.movieListService.getMovie(id).subscribe((movie: Movie) => {
        if (movie) {
          this.editForm.patchValue({
            id:id,
            title: movie.title,
            imageUrl: movie.imageUrl,
            boxOffice: movie.boxOffice,
            dateOfLaunch: movie.dateOfLaunch,
            active: movie.active,
            hasTeaser: movie.hasTeaser,
            genre: movie.genre
          });
        } 
        // else {
        //   this.router.navigate(['Not-Found']);
        // }

      });
    });
  }
  onSubmit(movie:any) {
    console.log(this.editForm);
    this.editMovie = true;
    // console.log(this.movieListService.modifyMovie(movie));
    this.movieListService.modifyMovie(movie).subscribe(data => {
      console.log('Movie update successful.');
      this.error = '';
    },
    error => {
      console.log(error);
      this.error = error.error.message;
      if (error.error.errors != null) {
        this.error = error.error.errors[0];
      }
    });

  }

}
