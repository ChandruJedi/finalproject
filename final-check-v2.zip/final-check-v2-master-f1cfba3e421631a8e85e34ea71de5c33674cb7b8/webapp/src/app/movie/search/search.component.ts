import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie';
import { MovieService } from '../../services/movie.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  movieFilter: Movie[];
  movies: Movie[];
  searchKey: string;
  constructor(private movieService: MovieService) {
  }
  search(event: any) {
    this.movieService.filter.next({ title: event.target.value });
  }

  ngOnInit() {
  }

}
