import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FavoritesService } from '../../services/favorites.service';
import { AuthService } from '../../services/auth.service';
import { LoginComponent } from 'src/app/site/login/login.component';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router: Router, private name: UserAuthService, private authService: AuthService) { 
  }
  authenticated(){
    return this.authService.loggedIn;
  }
  isAdmin(){
    return this.authService.isAdmin;
  }
  getUser(){
    return this.authService.userAuthenticated;
  }
  getName(){
    //console.log(this.name.getUserName())
    return this.name.getUserName();
  }
  signOut(){
    // this.favService.clearFav();
    this.authService.logOut();
    this.router.navigate([this.authService.navUrl]);
  }
  
  ngOnInit() {
    
  }

}
