import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie';
import { AuthService } from 'src/app/services/auth.service';
import { MovieService } from '../../services/movie.service';
import { FavoritesService } from 'src/app/services/favorites.service';
import { MovieListService } from 'src/app/services/movie-list.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  movies: Movie[];
  tempList: Movie[];
  constructor(private movieService: MovieService,private movieListService: MovieListService, private favorites: FavoritesService, private authService: AuthService,private movieList: MovieListService) {
    // this.movies = movieService.getMovieList();
  }
  ngOnInit() {
    this.movieListService.getAllMovies().subscribe((data) => {
      this.tempList = data;
      this.movies = data;
    }
    );
    this.movieService.filter.subscribe((obj: { title: string }) => {
      if (obj.title !== '') {
        const result = this.tempList.filter(movie => movie.title.toLowerCase().includes(obj.title.toLowerCase()));
        this.movies = result ? result : [];
      } else {
        this.movies = [...this.tempList];
      }
    });

  }
  addMovieToFav(id: number) {
    console.log("movie"+id);
    this.movieList.addFavoriteMovie(id).subscribe(()=>
      console.log("subs")
    );
    // this.router.url('/cart');
  }

}
