export interface Movie{
      id: number;
      title: string;
      dateOfLaunch: Date;
      boxOffice: number;
      hasTeaser: boolean;
      active: boolean;
      imageUrl: string;
      genre: string;
  }