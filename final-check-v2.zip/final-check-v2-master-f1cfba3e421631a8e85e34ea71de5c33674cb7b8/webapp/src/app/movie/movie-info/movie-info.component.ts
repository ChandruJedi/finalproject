import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { Movie } from '../movie';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-movie-info',
  templateUrl: './movie-info.component.html',
  styleUrls: ['./movie-info.component.css']
})
export class MovieInfoComponent implements OnInit {

  @Input() movie: Movie;
  itemAdded=false;
  cus=false;
 @Output() addedToFav: EventEmitter<number> = new EventEmitter<number>();
  constructor(private authService: AuthService, private router: Router) {
   
   }
  ngOnInit() {
    return this.movie.active;
  }
  onAddToFav(id:number){
    if (!this.authService.loggedIn){
      this.authService.setMovieId(id);
      this.router.navigate(['/login']);
    } else {
    console.log("movie info"+id);
    this.addedToFav.emit(id);
    this.itemAdded=true;
    setTimeout(()=>{
      this.itemAdded=false;
    },1000);
    return false;
  }
  }
  // customer(){
  //   if(this.movie.active){
  //     this.cus=true;
  //     console.log(this.movie);
  //     return this.cus;
  //   } else {
  //     this.cus=false;
  //     return this.cus;
  //   }
  // }
  ifAdmin(){
    return this.authService.isAdminUser() && this.authService.loggedIn;
  }
  ifLogged(){
    return this.authService.loggedIn;
  }

}
