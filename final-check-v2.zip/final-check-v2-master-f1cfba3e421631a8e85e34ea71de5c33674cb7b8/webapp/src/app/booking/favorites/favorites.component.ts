import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable, Observer } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { Favorites } from './favorites';
import { FavoritesService } from '../../services/favorites.service';
import { UserAuthService } from 'src/app/services/user-auth.service';
import { MovieListService } from 'src/app/services/movie-list.service';

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.css']
})
export class FavoritesComponent implements OnInit {
  favorites: Favorites;
  userId: string;
  error: any;
  isEmpty: boolean = true;

  constructor(private favService: FavoritesService, private userService: UserAuthService, private authService: AuthService, private movieListService: MovieListService) {
    this.movieListService.getAllFavorites().subscribe(data => {
      this.favorites = data;
      console.log(this.favorites);
      this.isEmpty = false;
    },
      error => {
        this.isEmpty = true;
      });
  }
  ngOnInit() {
  }
  removeItem(id: number) {
    console.log(id)
    this.userId = this.userService.getRole();
    this.movieListService.removeFavoriteMovie(this.userId, id).subscribe(data => {
      this.movieListService.getAllFavorites().subscribe((favorites) => {
        if (favorites) {
          console.log(favorites);
          this.isEmpty = false;
          this.favorites = favorites;
        }
      },
        (error) => {
          console.log(error.error.message);
          this.favorites.noOfFavorite = 0;
          this.error = error.error.message;
          this.isEmpty = true;
        })

    });
  }
  ifLogin() {
    return this.authService.isAdminUser() && this.authService.loggedIn;
  }
  ifCust() {
    return this.authService.loggedIn;
  }
}
