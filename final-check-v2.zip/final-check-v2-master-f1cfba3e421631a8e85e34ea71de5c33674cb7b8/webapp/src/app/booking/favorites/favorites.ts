import { Movie} from '../../movie/movie';
export interface Favorites{
    favorites: Movie[];
    noOfFavorite: number;
}