import { Injectable } from '@angular/core';
import { Movie } from '../movie/movie';
import { UserService } from './user.service';
import { User } from '../site/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loggedIn=false;
  isAdmin=false;
  isCustomer=false;
  accessToken:string;
  navUrl='/';
  names=false;
  userAuthenticated:User;
  movieId: number;
  constructor(private userService: UserService) { }
  logIn(username: string, password:string){
    this.userService.authenticate(username,password).subscribe((user:User)=>{
      if(user){
        this.loggedIn=true;
        this.userAuthenticated=user;
        this.isAdmin=user.role==='Admin';
        this.isCustomer=user.role==='Customer';
      }
    });
  }
  logOut(){
    this.navUrl='/';
    this.loggedIn=false;
  }
  username(first: string, last: string){
    return this.names;
  }
  isAdminUser(){
    return this.isAdmin;
  }
  setMovieId(id: number){
    console.log(id);
    // this.navUrl='/login';
    this.movieId=id;
  }
  getMovieId(){
    return this.movieId;
  }
}
