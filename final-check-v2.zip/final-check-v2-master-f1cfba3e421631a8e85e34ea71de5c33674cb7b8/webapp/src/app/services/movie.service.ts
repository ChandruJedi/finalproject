import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Movie } from '../movie/movie';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable, Observer, observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MovieService {
  configUrl = 'assets/movie-list.json';
  filter = new Subject();
  foodFilter: Movie[];
  finalFoods: Movie[];
  movies: Movie[];
  cusFood: Movie[];
  food: Movie;
  status: string;
  constructor(private link: HttpClient, private authService: AuthService) { }
  getMovieList(): Movie[] {
    return this.movies;
  }
  getMovies(): Observable<any> {
    return this.link.get(this.configUrl);
  }
  getMovie(id: number): Observable<any> {
    return Observable.create((observer: Observer<Movie>) => {
      this.getMovies().subscribe((movies: Movie[]) => {
        if (this.authService.isAdmin) {
          const item = movies.find(movie => movie.id == id);
          observer.next(item);
        } else {
          // if(foods.dateOfLaunch<new Date() && foods.isActive){
            
          const item = movies.find(movie => movie.id == id);
          observer.next(item);
          // }
        }
      });
    });
  }
}
