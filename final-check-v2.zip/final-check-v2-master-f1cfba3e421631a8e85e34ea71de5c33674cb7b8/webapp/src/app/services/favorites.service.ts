import { Injectable } from '@angular/core';
import { MovieService } from './movie.service';
import { Favorites } from '../booking/favorites/favorites';
import { Movie } from '../movie/movie';
import { v4 as uuid } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class FavoritesService {
  // favorites: Favorites = { items: null, noOfFav: 0 };

  // constructor(private movieService: MovieService) { }
  // getFav() { return this.favorites; }
  // addToFav(id: number, quantity: number) {
  //   console.log("adding");
  //   this.movieService.getMovie(id).subscribe((addMovie: Movie) => {
  //     const uid = uuid();
  //     if (this.favorites.items === null) {
  //       this.favorites.items = [{ itemId: uid, movie: addMovie, quantity }];
  //       this.favorites.noOfFav ++;
  //     } else {
  //       this.favorites.items.push({ itemId: uid, movie: addMovie, quantity });
  //       this.favorites.noOfFav ++;
  //     }
  //   });
  // }
  // removeFav(id: string) {
  //   const index = this.favorites.items.findIndex(item => item.itemId === id);
  //   const removeItem = this.favorites.items.splice(index, 1)[0];
  //   this.favorites.noOfFav --;
  // }
  // clearFav() {
  //   this.favorites.items = null;
  //   this.favorites.noOfFav = 0;
  // }
}
