import { Injectable } from '@angular/core';
import { Movie } from '../movie/movie';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { UserAuthService } from './user-auth.service';
import { environment } from 'src/environments/environment';
import { Favorites } from '../booking/favorites/favorites';
import { WebDriverLogger } from 'blocking-proxy/built/lib/webdriver_logger';

@Injectable({
  providedIn: 'root'
})
export class MovieListService {
  private movieUrl = 'http://localhost:8083/movies';
  private baseU = environment.baseUrl + '/favorites';
  userId: string;
  constructor(private httpClient: HttpClient, private authenticationService: UserAuthService) { }

  public getAllMovies(): Observable<Movie[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.get<Movie[]>(this.movieUrl, httpOptions);
  }
  public getMovie(id: number): Observable<any> {
    //this.httpClient.get<Food[]>(this.menuUrl+'[id]');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.get<Movie>(this.movieUrl + "/" + id, httpOptions);
  }
  modifyMovie(movie: Movie): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.put<void>(this.movieUrl, movie, httpOptions);
  }

  addFavoriteMovie(movieId: number): Observable<void> {
    console.log(this.userId);
    console.log(movieId);
    console.log(this.authenticationService.getRole());
    console.log(this.authenticationService.getUserName());
    this.userId = this.authenticationService.getUserName();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    console.log(this.baseU + "/" + this.userId + "/" + movieId);
    return this.httpClient.post<void>(this.baseU + "/" + this.userId + "/" + movieId, {}, httpOptions);
  }

  getAllFavorites(): Observable<any> {
    console.log(this.authenticationService.getRole());
    console.log(this.authenticationService.getUserName());
    this.userId = this.authenticationService.getUserName();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    console.log(this.userId);
    return this.httpClient.get<Favorites>(this.baseU + "/" + this.userId, httpOptions);
  }

  removeFavoriteMovie(userId: string, movieId: number): Observable<void> {
    // this.userId=this.authenticationService.getRole();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.delete<void>(this.baseU + "/" + this.userId + "/" + movieId, httpOptions);
  }


}
