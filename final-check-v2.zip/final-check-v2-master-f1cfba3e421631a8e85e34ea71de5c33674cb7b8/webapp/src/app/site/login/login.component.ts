import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login=true;
  authSource:string;
  error: string;
  constructor(private router: Router, private userAuth: AuthService,private authenService: UserAuthService,private route: ActivatedRoute, private authService: AuthService){} 

  ngOnInit() {
    this.login = !(this.authService.loggedIn);
    this.route.queryParams.subscribe((params:Params)=>{
      this.authSource=params['from'];
    });
  }
  onSubmit(form: NgForm){
    const id=form.value.id;
    const username=form.value.username;
    const password=form.value.password;
    console.log(username);
    console.log(username);
      this.authenService.authenticate(username,password).subscribe((data)=>{
      this.authService.logIn(username,password);
      this.router.navigate(['movies']);
      this.authenService.setToken(data.token);
    }, (error) => {
      this.login = false;
      if (error.status == 401) {
        console.log("Invalid Usename/Password");
        this.error = "Invalid Usename/Password";
      }

    });
  }
  // ifInvalid(){
  //   return this.login;
  // }

}
