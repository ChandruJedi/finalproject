import { Component, OnInit } from '@angular/core';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';
import { User } from '../user';
import { UserService } from 'src/app/services/user.service';
import { createVerify } from 'crypto';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  editSign: FormGroup;
  user: User;
  userPresent: boolean=false;
  error: string;
  verify: false;
  passValid: boolean;
  constructor(private router: Router,private userService : UserService, private authService: AuthService) { }

  ngOnInit() {
    this.editSign = new FormGroup({
      // 'id':new FormControl(null),
      firstname: new FormControl(null, Validators.required),
      lastname: new FormControl(null),
      username: new FormControl(null, Validators.required),
      password: new FormControl(null),
      cpassword:new FormControl(null)
      // 'id': new FormControl(null),
      // 'accessToken': new FormControl(null),
      // 'role': new FormControl(null),
    
    });
  }
  onSubmit(){
    // this.user=this.editSign.value;
    // console.log(this.editSign);
    // this.userService.addUser(this.user).subscribe(
    //   (data)=>{
    //     this.router.navigate(['/login']);
    //   },
    //   (errorData)=>{
    //     this.error=errorData.error.errorMessage;
    //     this.userPresent=true;
    //   }
    //)
    this.user=this.editSign.value;
    console.log(this.user);
    if (this.editSign.value.password != this.editSign.value.cpassword) {
      this.passValid = true;
    } else {
    this.userService.addUser(this.user).subscribe(
      (response) => {
        this.router.navigate(['/login']);
      },
      (responseError) => {
        this.error = responseError.error.errorMessage;
        this.userPresent=true;
      }
     );
    }
  }
}
