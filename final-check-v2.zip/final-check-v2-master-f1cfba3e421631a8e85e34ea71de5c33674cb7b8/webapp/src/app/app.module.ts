import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieInfoComponent } from './movie/movie-info/movie-info.component';
import { FavoritesComponent } from './booking/favorites/favorites.component';
import { Routes, RouterModule } from '@angular/router';
import { MoviesComponent } from './movie/movies/movies.component';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { SearchComponent } from './movie/search/search.component';
import { HeaderComponent } from './movie/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MovieEditComponent } from './movie/movie-edit/movie-edit.component';
import { HttpClientModule } from '@angular/common/http';
import { AuthGuardService } from './services/auth-guard.service';
import { MovieService } from './services/movie.service';
import { FavoritesService } from './services/favorites.service';


export const routes: Routes =[
    { path: 'movies', component: MoviesComponent },
    { path: 'favorites', component: FavoritesComponent, canActivate: [AuthGuardService]},
    { path: 'login', component: LoginComponent },
    { path: 'login/signup', component: SignupComponent},
    { path: 'signup', component: SignupComponent },
    { path: '', redirectTo: 'movies', pathMatch: 'full' },
    { path: 'movieEdit/:id', component: MovieEditComponent, canActivate: [AuthGuardService] },


  ];

@NgModule({
  declarations: [
    AppComponent,
    MovieInfoComponent,
    MoviesComponent,
    SearchComponent,
    FavoritesComponent,
    HeaderComponent,
    MovieEditComponent,
    LoginComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [MovieService, FavoritesService],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }
